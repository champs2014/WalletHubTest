package com.ef.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "blocked_ip", catalog = "parser")
public class BlockedIp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IP_ID", unique = true, nullable = false)
	private long ipId;
	
	@Column(name = "IP", unique = false, nullable = false, length=20)
	private String ip;
	
	@Column(name = "NUMBER_REQUESTS", unique = false, nullable = false)
	private Integer numberRequests;
	
	@Column(name = "BLOCK_COMMENT", unique = false, nullable = false, length=300)
	
	private String blockComment;

	public long getIpId() {
		return ipId;
	}

	public void setIpId(long ipId) {
		this.ipId = ipId;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Integer getNumberRequests() {
		return numberRequests;
	}

	public void setNumberRequests(Integer numberRequests) {
		this.numberRequests = numberRequests;
	}

	public String getBlockComment() {
		return blockComment;
	}

	public void setBlockComment(String blockComment) {
		this.blockComment = blockComment;
	}
	
	
}
