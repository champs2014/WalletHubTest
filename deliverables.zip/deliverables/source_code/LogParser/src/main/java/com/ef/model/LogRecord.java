package com.ef.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "log_record", catalog = "parser")
public class LogRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LOG_RECORD_ID", unique = true, nullable = false)
	private long logRecordId;
	
	@Column(name = "REQUEST_DATE", unique = false, nullable = false)
	private Date requestDate;
	
	@Column(name = "IP", unique = false, nullable = false, length=20)
	private String ip;
	
	@Column(name = "REQUEST", unique = false, nullable = false, length=100)
	private String request;
	
	@Column(name = "STATUS", unique = false, nullable = false)
	private Integer status;
	
	@Column(name = "USER_AGENT", unique = false, nullable = false, length=300)
	private String userAgent;

	public long getLogRecordId() {
		return logRecordId;
	}

	public void setLogRecordId(long logRecordId) {
		this.logRecordId = logRecordId;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	
}
