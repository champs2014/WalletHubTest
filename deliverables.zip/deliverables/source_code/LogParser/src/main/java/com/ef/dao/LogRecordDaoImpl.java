package com.ef.dao;

import org.hibernate.Session;

import com.ef.model.LogRecord;
import com.ef.persistence.HibernateUtil;

public class LogRecordDaoImpl implements LogRecordDao {

	public void saveLogRecord(LogRecord logRecord) {
		Session session = null;
		
		try {
			session = HibernateUtil.getSessionFactory().openSession();			
			session.beginTransaction();
			session.save(logRecord);			
			session.getTransaction().commit();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			session.close();
		}
	}
}
