package com.ef.vo;

public class BlockedIpVo {

	private String ip;
	private Integer quantityOccurrence;
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Integer getQuantityOccurrence() {
		return quantityOccurrence;
	}
	public void setQuantityOccurrence(Integer quantityOccurrence) {
		this.quantityOccurrence = quantityOccurrence;
	}
}
