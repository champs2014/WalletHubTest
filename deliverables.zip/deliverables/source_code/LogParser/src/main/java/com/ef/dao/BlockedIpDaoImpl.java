package com.ef.dao;

import org.hibernate.Session;

import com.ef.model.BlockedIp;
import com.ef.persistence.HibernateUtil;

public class BlockedIpDaoImpl implements BlockedIpDao {
	
	public void saveBlockedIp(BlockedIp blockedIp) {
		Session session = null;
		
		try {
			session = HibernateUtil.getSessionFactory().openSession();			
			session.beginTransaction();
			session.save(blockedIp);
			session.getTransaction().commit();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally {
			session.close();
		}
	}
}
