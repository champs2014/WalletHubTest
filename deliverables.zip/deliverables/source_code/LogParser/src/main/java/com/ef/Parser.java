package com.ef;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.ef.dao.BlockedIpDao;
import com.ef.dao.BlockedIpDaoImpl;
import com.ef.dao.LogRecordDao;
import com.ef.dao.LogRecordDaoImpl;
import com.ef.model.BlockedIp;
import com.ef.model.LogRecord;
import com.ef.vo.BlockedIpVo;

public class Parser {

	public static void main(String[] args) {
		System.out.println("STARTING!!!");
		System.out.println("");
		System.out.println("");
		Parser parseLog = new Parser();
		try {
			parseLog.parse(args);
		} catch (IOException e) {
			System.out.println("");
			System.out.println("THE LOG FILE HAVE ERRORS OR DON'T EXIST, PLEASE, VERIFY!!!");
			System.out.println("");
			e.printStackTrace();
		} catch (ParseException e) {
			System.out.println("");
			System.out.println("PROBLEMS DURING THE LOG FILE PARSE, PLEASE, VERIFY!!!");
			System.out.println("");
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("");
			System.out.println("OCCURRED A PROBLEM DURING THE PROGRAM EXECUTION!!!");
			System.out.println("");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("");
			System.out.println("OCCURRED A PROBLEM DURING THE PROGRAM EXECUTION!!!");
			System.out.println("");
			e.printStackTrace();
		}
		
		System.out.println("");
		System.out.println("");
		System.out.println("GOOD BYE!!!");
		System.exit(0);
	}
	
	/*
	 * Main parse method
	 */
	public void parse(String[] args) throws IOException, ParseException, NullPointerException {
		//Recovering the parameters values
		Path path = Paths.get(splitParameter(args[0], "="));
		String initialTimeParam = splitParameter(args[1], "=");
		String timeMode = splitParameter(args[2], "=");
		Integer ipLimit = Integer.parseInt(splitParameter(args[3], "="));
		
		Integer timeModeOption = 0;
		HashMap<String, Integer> ipMap = new HashMap<String, Integer>();
		List<BlockedIpVo> blockedIpVoList = new ArrayList<BlockedIpVo>();
		List<BlockedIp> blockedIpList = new ArrayList<BlockedIp>();
		List<LogRecord> logRecordList = new ArrayList<LogRecord>();
		Integer blockedIpCount = 0;
		Integer logRecordCount = 0;
		
		//Selecting the duration mode
		if (timeMode.equalsIgnoreCase("hourly")) {
			timeModeOption = 1;
		} else if(timeMode.equalsIgnoreCase("daily")) {
			timeModeOption = 2;
		}
		
		//Calculating the end date based on initial date
		Timestamp initialTimestamp = formatDate("yyyy-MM-dd.hh:mm:ss", initialTimeParam);
		Timestamp endTimestamp = calculateEndDate(initialTimestamp, timeModeOption);
		Timestamp logTimestamp = null;
		
		
		//Parsing the log file to find the blocked ips
		for (String line: Files.readAllLines(path,StandardCharsets.US_ASCII)) {
			int i = 0;
			
			for (String content : line.split("\\|", 0)) {
				if (i == 0) {
					logTimestamp = formatDate("yyyy-MM-dd hh:mm:ss.SSS", content);				    
				}
				else if (i == 1) {
					if (verifyTimestampRange(initialTimestamp, endTimestamp, logTimestamp)) {
						ipMap = addIpMap(ipMap, content);
					}
					break;
				}
				i++;
			}
		}
		
		//Selecting the blocked ips based on the number of requests
		blockedIpVoList = checkBlockedIpOccurrence(ipMap, ipLimit);
		
		System.out.println("BLOCKED IPS: ");
		System.out.println("");
		
		//Preparing blocked ips model for persistence
		for (BlockedIpVo blockedIpVo : blockedIpVoList) {
			BlockedIp blockedIp = new BlockedIp();
			blockedIp.setIp(blockedIpVo.getIp());
			System.out.println(blockedIpVo.getIp());
			
			if (timeModeOption == 1) {
				blockedIp.setBlockComment("IP BLOCKED BECAUSE MADE " + blockedIpVo.getQuantityOccurrence() + " REQUESTS DURING ONE HOUR");
			} else if (timeModeOption == 2) {
				blockedIp.setBlockComment("IP BLOCKED BECAUSE MADE " + blockedIpVo.getQuantityOccurrence() + " REQUESTS DURING ONE DAY");
			}
			
			blockedIp.setNumberRequests(blockedIpVo.getQuantityOccurrence());
			
			blockedIpList.add(blockedIp);
		}
		
		System.out.println("");
		System.out.println("STILL PROCESSING...");
		System.out.println("");
		
		/*
		 * Parsing the log file to find the remaining log records belonging to the blocked ips.
		 * The loop also prepare log record model for persistence
		 */
		for (String line: Files.readAllLines(path,StandardCharsets.US_ASCII)) {
			int i = 0;
			
			for (BlockedIpVo blockedIpVo : blockedIpVoList) {
				
				String ipToCompare = blockedIpVo.getIp();
				
				LogRecord logRecord = null;
				boolean ipMatch = false;
				
				for (String content : line.split("\\|", 0)) {
					switch(i) {
						case 0:
							logTimestamp = formatDate("yyyy-MM-dd hh:mm:ss.SSS", content);
							break;
						case 1:
							if (ipToCompare.equals(content)) {
								logRecord = new LogRecord();
								logRecord.setRequestDate(logTimestamp);
								logRecord.setIp(content);
								ipMatch = true;
							}
							break;
						case 2:
							if (ipMatch) {
								logRecord.setRequest(content);
							}
							break;
						case 3:
							if (ipMatch) {
								logRecord.setStatus(Integer.parseInt(content));
							}
							break;
						case 4:
							if(ipMatch) {
								logRecord.setUserAgent(content);
							}
							break;
					}
					i++;
				}
				
				if (i > 4) {
					if (ipMatch) {
						logRecordList.add(logRecord);
						i = 0;
						break;
					}
					i = 0;
				}
			}
		}
		
		System.out.println("");
		System.out.println("STARTING LOAD ON DATABASE!!!");
		System.out.println("");
		
		//Creating blocked ip dao and persisting the blocked ips
		BlockedIpDao blockedIpDao = new BlockedIpDaoImpl();
		
		for (BlockedIp blockedIp : blockedIpList) {
			blockedIpDao.saveBlockedIp(blockedIp);
			blockedIpCount++;
		}
		
		System.out.println("");
		System.out.println("BLOCKED IPS LOAD ON DATABASE DONE. TOTAL OF " + blockedIpCount + " RECORDS LOADED");
		System.out.println("");
		
		System.out.println("");
		System.out.println("STILL LOADING ON DATABASE...");
		System.out.println("");
		
		//Creating log record dao and persisting the log records
		LogRecordDao logRecordDao = new LogRecordDaoImpl();
		
		for (LogRecord logRecord : logRecordList) {
			logRecordDao.saveLogRecord(logRecord);
			logRecordCount++;
		}
		
		System.out.println("LOG RECORDS LOAD ON DATABASE DONE. TOTAL OF " + logRecordCount + " RECORDS LOADED");
		System.out.println("");
	}
	
	//To separate the entry parameter names from parameter values
	private String splitParameter(String parameter, String splitPattern) {
		String result = parameter.split(splitPattern)[1];
		return result;
	}
	
	//Verify if the log record date it's on the range passed on parameter
	private boolean verifyTimestampRange(Timestamp initialTimestamp, Timestamp endTimestamp, Timestamp logTimestamp) {
		boolean result = false;
		
		if ((logTimestamp.after(initialTimestamp) || logTimestamp.equals(initialTimestamp)) && 
			(logTimestamp.before(endTimestamp) || logTimestamp.equals(endTimestamp))) {
			result = true;
		}
		
		return result;
	}
	
	//To format the date
	private Timestamp formatDate(String dateFormatPattern, String dateToFormat) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormatPattern);
		
		String dateToParse = dateToFormat;
		Date dateParsed = dateFormat.parse(dateToParse);
	    Timestamp timestamp = new Timestamp(dateParsed.getTime());
	    
	    return timestamp;
	}
	
	//To calculate the end date according to duration mode
	private Timestamp calculateEndDate(Timestamp initialDate, Integer timeModeOption) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(initialDate);
		
		switch(timeModeOption) {
			case 1:
				calendar.add(Calendar.HOUR, 1);
				break;
			case 2:
				calendar.add(Calendar.HOUR, 24);
				break;
		}
		
		Timestamp endDate = new Timestamp(calendar.getTimeInMillis());
		
		return endDate;
	}
	
	//To reference the number of request to it corresponding ip
	private HashMap<String, Integer> addIpMap(HashMap<String, Integer> ipMap, String ipAddress) {
		ipMap.computeIfPresent(ipAddress, (k, v) -> v + 1);
		ipMap.computeIfAbsent(ipAddress, n -> 1);
		return ipMap;
	}
	
	//To verify if the ip made a certain number of requests
	private List<BlockedIpVo> checkBlockedIpOccurrence(HashMap<String, Integer> ipMap, Integer ipLimit) {
		List<BlockedIpVo> blockedIpList = new ArrayList<BlockedIpVo>();
		
		for (String key : ipMap.keySet()) {
			Integer value = ipMap.get(key);
			if(value >= ipLimit) {
				BlockedIpVo blockedIpVo = new BlockedIpVo();
				blockedIpVo.setIp(key);
				blockedIpVo.setQuantityOccurrence(value);
				blockedIpList.add(blockedIpVo);
			}
		}
		
		return blockedIpList;
	}

}
