package com.ef.dao;

import com.ef.model.LogRecord;

public interface LogRecordDao {

	public abstract void saveLogRecord(LogRecord logRecord);
}
