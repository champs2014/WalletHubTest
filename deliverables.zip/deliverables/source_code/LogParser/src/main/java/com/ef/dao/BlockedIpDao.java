package com.ef.dao;

import com.ef.model.BlockedIp;

public interface BlockedIpDao {
	
	public abstract void saveBlockedIp(BlockedIp blockedIp);
}
